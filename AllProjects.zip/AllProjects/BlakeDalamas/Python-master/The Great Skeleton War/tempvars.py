memory_name = "Error!"
memory_sound = None
