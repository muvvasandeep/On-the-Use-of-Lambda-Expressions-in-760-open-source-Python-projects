# INPUT NUMBER OF ODD NUMBERS

n=int(input('Amount: '))
start=1

for i in range(n):
  print(start)
  start+=2
