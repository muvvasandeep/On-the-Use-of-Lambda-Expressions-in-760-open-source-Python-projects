dec_num = input('Enter the decimal number\n')
print(hex(int(dec_num)))
